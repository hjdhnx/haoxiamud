<?php

 $_USERS = array (
  0 => 
  array (
    'name' => 'admin',
    'pass' => '$1$Qyhkm8oi$wyUAuq2CFI0m0vkfeo5.U/',
    'role' => 'superadmin',
  ),
);
