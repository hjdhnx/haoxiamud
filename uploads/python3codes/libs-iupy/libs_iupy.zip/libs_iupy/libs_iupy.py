from urllib import request#从url库中引用request函数
import urllib#引入urllib库
import os#引入文件系统库
import time#引入时间库
import re#导入正则函数库
class downloadimg:
      '''
      主函数可传参数url,name,path,User_Agent,Referer分别对应下载直链,欲保存名称,保存路径,协议头User_Agent,协议头Referer
      下载直链url（必填参数）
      欲保存名称name（必填参数）
      保存路径path（选填参数，默认值为'img/'运行程序相同文件夹下的img文件夹）
      协议头User_Agent（选填参数，默认值模拟Chrome浏览器）
      协议头Referer（选填参数，默认值为空）
      内部调用函数getheaders()返回本次请求的完整协议头headers
      '''
      mypath='img/'#文件默认下载路径为在程序相同目录下新建一个img文件夹
      url=''#待下载的纯文件链接
      User_Agent='Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1941.0 Safari/537.36'
      Referer=''#User-Agent和Referer都是浏览器协议头的组成部分。大部分网址反爬虫会验证协议头，否则返回403forbiddden
      name=''#待下载的文件需要保存的文件名
      headers=[('User-Agent',User_Agent),('Referer',Referer)]#完整协议头
      def __init__(self,url,name,path=mypath,User_Agent=User_Agent,Referer=Referer):#默认协议头header未传参时将使用类中自带的对象
       self.url=url
       self.name=name
       self.User_Agent=User_Agent
       self.Referer=Referer
       self.headers=[('User-Agent',User_Agent),('Referer',Referer)]
       self.mypath=path+name
       opener = request.build_opener()
       opener.addheaders=self.headers
       request.install_opener(opener)
       try:
        if not os.path.exists(path):#目录不存在创建目录
          print('正在创建{}目录'.format(path))
          os.mkdir(path)
        if os.path.exists(self.mypath):
          print('发现已有该文件，下载将自动生成时间副本文件')
          mypath=path+'副本_{}_'.format(str(time.time())[0:-7])+name
          request.urlretrieve(self.url, mypath)
        if not os.path.exists(self.mypath):#文件不存在则下载
          print('正在下载{}到{}目录'.format(name,self.mypath))
          request.urlretrieve(self.url, self.mypath)   
       except urllib.error.HTTPError:
          print('发生了403错误，资源下载被禁止，可能是请求协议头不正确')
          pass
      def getheaders(self):
          print('本次请求协议头为:{}\n'.format(self.headers))
          return self.headers
class geturlcode:
      '''
      主函数可传参数page,encode,User_Agent,Referer分别对应静态页面,页面编码,协议头User_Agent,协议头Referer
      静态页面page（必填参数）
      页面编码encode（选参数，默认值为'utf-8',能自动识别正确网页编码，推荐不填写）
      协议头User_Agent（选填参数，默认值模拟Chrome浏览器）
      协议头Referer（选填参数，默认值为空）
      内部调用函数getencode()返回本次请求网页源码的正确编码
      内部调用函数geturlcode()返回本次请求得到的正确编码后的网页源码
      '''
      page=''#默认请求网页（一般为html文件）
      urlcode=''
      encode='utf-8'#网页默认编码，常见的utf-8,gb2312等
      User_Agent='Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1941.0 Safari/537.36'
      Referer=''#User-Agent和Referer都是浏览器协议头的组成部分。大部分网址反爬虫会验证协议头，否则返回403forbiddden  
      headers={'User-Agent':User_Agent,'Referer':Referer}#完整协议头
      def __init__(self,page,encode=encode,User_Agent=User_Agent,Referer=Referer):
       self.User_Agent=User_Agent
       self.Referer=Referer
       self.headers={'User-Agent':User_Agent,'Referer':Referer}
       req = request.Request(url=page, headers=self.headers)
       response=request.urlopen(req)
       self.urlcode = response.read().decode(encode,'ignore')
       link="(.*)charset=(.*?)>"#这里用(.*?)而不用(.*)是为了最少的匹配，不开启贪婪模式
       charset_lis=re.search(link,self.urlcode,re.I)
       charset=str(charset_lis[2])
       self.encode=re.sub(r'[\"|\'|\/|\ ]', '',charset)#替换单双引号和/以及空格
       print('匹配到网页编码为:{},编码字符长度为:{}'.format(self.encode,len(self.encode)))
       try:
         if self.encode.lower()=='utf-8':#字符串转换小写后判断相等
            print('正常获取网页源码!')
            #print('输出网页源码:\n{}'.format(self.urlcode))
         else:
            print('编码不符,正在重新编码并返回网页源码')
            response=request.urlopen(req)
            self.urlcode= response.read().decode(self.encode,'ignore')
            #print('输出网页源码:\n{}'.format(self.urlcode))
       except  LookupError:
            print('编码获取失败{}'.format(charset))
       except  TypeError:
            print('编码获取失败{}'.format(charset))    
      def getencode(self):
           print('网页访问编码为:{}'.format(self.encode))
           return self.encode
      def geturlcode(self):
           print('输出网页源码:\n{}'.format(self.urlcode))
           return(self.urlcode)
class getimglist:
      '''
      主函数可传参数urlcode,imgtype,mode分别对应 网页源码,图片类型,图片模式
      网页源码urlcode（必填参数）
      图片类型imgtype（选填参数，默认值为'.jpg'）
      图片模式mode（选填参数，默认值为'u',可选值有u/d,'u'表示以url作为图片真实地址。'd'表示以data-original作为图片真实地址）
      内部调用函数getlist()返回本次请求得到的图片下载直链列表
      内部调用函数getnum()返回本次请求得到的图片下载直链列表总长度，即可下载的图片总数
      '''
      urlcode=''#正确的网页源代码
      imgtype='.jpg'#图片的格式
      imglist=[]#定义一个列表用于储存所有图片直链
      imgnums=0#定义匹配到一个页面上所有图片的总数
      def __init__(self,urlcode,imgtype='jpg',mode='u'):#可传参数为网页源码,图片类型,图片模式u/d u表示以url作为图片真实地址。d表示以data-original作为图片真实地址，默认直链url
          self.urlcode=urlcode
          self.imgtype=imgtype
          if mode=='u':
             link=r"src=(.*){}(.*?)>".format(imgtype)
          elif mode=='d':
             link=r"data-original=(.*){}(.*?)>".format(imgtype)
          try:
              print('待匹配链接格式为:{}'.format(link))
              img_lis=re.findall(link,self.urlcode,re.I)
              for i in img_lis:
                  words=re.sub(r'\"|\'','',i[0])
                  self.imglist.append(words+imgtype)              
              self.imgnums=len(self.imglist)
              #print(self.imglist)#输出匹配完成后的下载列表
          except  LookupError:
              print('编码获取失败')              
      def  getlist(self):
           #print('待下载的图片集为:\n{}'.format(self.imglist))
           return  self.imglist     
      def  getnum(self):
           #print('待下载的图片集内图片总数为:{}'.format(self.imgnums))
           return  self.imgnums     
class downall:
      '''
      主函数可传参数page,name,mypath,imgtype,mode分别对应网址,欲保存图片名字前缀,保存路径,匹配图片类型,图片模式
      网址page（必填参数）
      欲保存图片名字前缀name（必填参数）
      保存路径mypath（选填参数，默认值为'img/pics/'）
      匹配图片类型imgtype（选填参数，默认值为'.jpg'）
      图片模式mode（选填参数，默认值为'u',可选值有u/d,'u'表示以url作为图片真实地址。'd'表示以data-original作为图片真实地址）
      调用downall(page)可以实现下载page页面上所有符合匹配条件的图片并保存到本地
      '''
      def __init__(self,page,name,mypath='img/pics/',imgtype='.jpg',mode='u'):
          urlcode=geturlcode(page)
          referer=re.match(r'(.*?)//(.*?)/'.format('.'),page,re.I)
          homeurl=str(referer[0])
          imglist=getimglist(urlcode.geturlcode(),imgtype,mode)
          num=imglist.getnum()
          imgs=imglist.getlist()
          print('共有{}张图片'.format(num))
          for i in range(num):
              downloadimg(imgs[i],'{}-{}.jpg'.format(name,i),path=mypath,Referer=homeurl)
       
if __name__=='__main__':#被引入时下面代码不执行
    #t=downloadimg('https://pic2016.ytqmx.com/2019/0124/210/3.jpg!220.jpg','1.png',Referer='https://www.5442.com/')
    #print('本次请求协议头为:{}\n'.format(t.getheaders()))
    #t=downloadimg('https://i.meizitu.net/thumbs/2019/01/167924_06c08_236.jpg','2.jpg',Referer='https://www.mzitu.com/')
    #t.getheaders()
    #t=geturlcode('https://www.5442.com/keywords/luotiyishu.html')
    #g=getimglist(t.geturlcode(),'.jpg')
    #g.getnum()
    downall('https://www.5442.com/keywords/rbmnyb.html','美女5422')
   
