from libs_iupy import downloadimg
from libs_iupy import geturlcode
from libs_iupy import getimglist
import re

def downall(page,name,mypath='img/1/',imgtype='.jpg',mode='u'):
    urlcode=geturlcode(page)
    referer=re.match(r'(.*?)//(.*?)/'.format('.'),page,re.I)
    homeurl=str(referer[0])
    imglist=getimglist(urlcode.geturlcode(),imgtype,mode)
    num=imglist.getnum()
    imgs=imglist.getlist()
    print('共有{}张图片'.format(num))
    for i in range(num):
        t=downloadimg(imgs[i],'{}-{}.jpg'.format(name,i),path=mypath,Referer=homeurl)
if __name__=='__main__':
  downall('https://www.5442.com/keywords/rbmnyb.html','美女5422','img/1/')